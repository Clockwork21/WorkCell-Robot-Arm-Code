/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  Arm Display Position                                      */
/*                                                                            */
/*    This example will continuously display the current                      */
/*    position of the arm on the brain's screen                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, 1, 2, 3, 4
// EStop                bumper        E               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int displayPositionLoop() {

  Brain.Screen.setFont(mono60);
  
  while (true) {
    Brain.Screen.clearScreen();

    // Display the X position on row 1
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("X: %.3f", RoboticArm1.getAxisPosition(xaxis));

    // Display the Y position on row 2
    Brain.Screen.newLine();
    Brain.Screen.print("Y: %.3f", RoboticArm1.getAxisPosition(yaxis));

    // Display the Z position on row 3
    Brain.Screen.newLine();
    Brain.Screen.print("Z: %.3f", RoboticArm1.getAxisPosition(zaxis));

    wait(0.2, seconds);
  }
  return 0;
}

// This is the function we want to run when the emergency stop button
// is pressed. It will tell the arm to stop moving.
void onEStopPressed() {
  RoboticArm1.emergencyStop();
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Link the emergency stop button pressed event with the onEStopPressed function
  EStop.pressed(onEStopPressed);

  // Start task to continuously display the current arm position
  vex::task displayPositionTask(displayPositionLoop);

  // Set up the arm with the initial configuration values
  RoboticArm1.setMasteringValues(1836,2167,2013,474);
  RoboticArm1.setToolTipOffset(1.05, 0.0, -1.0);
  int startZ = 2.0;
  double topLine = 6.0;
  double bottomLine = 8.730;
  double middleLine = ((topLine + bottomLine)/2);
  RoboticArm1.moveToPositionLinear(topLine, -5.489, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, -5.489, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, -4.084, startZ);
  RoboticArm1.moveToPositionLinear(topLine, -3.197, startZ);
  RoboticArm1.moveToPositionLinear(topLine, -3.197, startZ+1);

  RoboticArm1.moveToPositionLinear(topLine, -2.197, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, -2.197, startZ);
  RoboticArm1.moveToPositionLinear(topLine, -0.197, startZ);
  RoboticArm1.moveToPositionLinear(topLine, -0.197, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, -2.197, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, -2.197, startZ);
  RoboticArm1.moveToPositionLinear(middleLine, -2.197, startZ);
  RoboticArm1.moveToPositionLinear(middleLine, -0.197, startZ);
  RoboticArm1.moveToPositionLinear(middleLine, -2.197, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, -2.197, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, -0.197, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, -0.197, startZ+1);

  RoboticArm1.moveToPositionLinear(topLine, 1.27, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, 1.27, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, 3.2, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, 3.2, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, 3.2, startZ+1);
  RoboticArm1.moveToPositionLinear(topLine, 3.2, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, 1.27, startZ);
  RoboticArm1.moveToPositionLinear(bottomLine, 1.27, startZ+1);
  RoboticArm1.moveToPositionLinear(middleLine, 0, startZ+1);
  //RoboticArm1.moveToPositionLinear(
  return 0;
}

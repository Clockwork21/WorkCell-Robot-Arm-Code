  /*----------------------------------------------------------------------------*/
  /*                                                                            */
  /*    Module:       main.cpp                                                  */
  /*    Author:       VEX                                                       */
  /*    Created:      Tue Mar 16 2021                                           */
  /*    Description:  Arm UI Panel                                              */
  /*                                                                            */
  /*    This example will configure the Workcell Arm and display                */
  /*    a basic UI on the V5 Brain's screen that you can configure              */
  /*                                                                            */
  /*----------------------------------------------------------------------------*/

  // ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RoboticArm1          RoboticArm    1, 2, 3, 4, A, B, C, D
// EStop                bumper        E               
// Magnet5              electromagnet 5               
// Optical6             optical       6               
// ---- END VEXCODE CONFIGURED DEVICES ----

  #include "vex.h"

  using namespace vex;

  // Function to run when the V5 Brain's screen is pressed
double Magnet5_duration = 1000.0;
float zHeight;

  int whenStart1(){
    RoboticArm1.setMasteringValues(1836.0, 2167.0, 2013.0, 474.0);
    RoboticArm1.setToolTipOffset(-0.7, 0.0, -1.0);
    Magnet5.setPower(100);
    Optical6.setLightPower(100, percent);
    Magnet5_duration = 1000.0;
    zHeight = 3.25;
    
    return 0;
  }
  void onScreenPressed_0() {
        
    
    RoboticArm1.moveToPositionJoint(7.744, -5.845, 5);
    wait(1, seconds);
    RoboticArm1.moveToPositionJoint(7.735, -6.0, zHeight);
    wait(1, seconds);
    Magnet5.pickup(Magnet5_duration);
    RoboticArm1.moveToPositionJoint(7.300, -5.475, 5);
    RoboticArm1.moveToPositionJoint(7.569, -1.611, 5);
    wait(1, seconds);
    if(Optical6.color() == red){
      RoboticArm1.moveToPositionJoint(8.762, 1.752, 5);
      wait(1, seconds);
      Magnet5.drop();
      zHeight = zHeight + -1.0;

    }
    if(Optical6.color() == blue){
      RoboticArm1.moveToPositionJoint(8.844, 4.500, 5);
      wait(1, seconds);
      Magnet5.drop();
      zHeight = zHeight + -1.0;

    }
    if(Optical6.color() == green){
      RoboticArm1.moveToPositionJoint(7.261, 4.312, 5);
      wait(1, seconds);
      Magnet5.drop();
      zHeight = zHeight + -1.0;
    }
    
  }
  

  // Function to run when the emergency stop button is pressed
  void onEStopPressed() {
    RoboticArm1.emergencyStop();
  }

  int main() {
    // Initializing Robot Configuration. DO NOT REMOVE!
    vexcodeInit();

    
    
    // register event handlers
    Brain.Screen.pressed(onScreenPressed_0);
    EStop.pressed(onEStopPressed);

    wait(15, msec);
    

    // configure the arm
    
    
    whenStart1();

  }
